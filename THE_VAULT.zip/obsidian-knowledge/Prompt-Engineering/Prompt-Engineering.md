---
tags: [prompt-engineering, patterns, tips]
created: 2026-05-22
aliases: [Prompt Patterns, Prompt Tips]
---

# 🧠 Prompt Engineering

> *Patterns, tips, and reusable structures for prompts. Seeded by Boris (Anthropic) speech + daily learnings.*

## Core Patterns

### 🎭 Role Prompting ("You are a...")
⚠️ **OVERUSED.** Loses task nuance. Just describe the actual task honestly instead of assigning a persona.

### 🔗 Chain of Thought
✅ **WORKS.** But content matters — it's not just "more computation space." Structure the reasoning, don't just say "think step by step."

### 📚 Multi-Shot Examples
✅ **Very effective** for text. Less effective for images. Provide 2-3 examples showing the pattern.

### 🎨 Metaphors
⚠️ **Can help** but hard to get right. Default to clear description first before reaching for metaphor.

---

## Claude-Specific Tips

### 📖 Claude Documentation
- Read the official docs — they're genuinely useful
- Understand context window management
- Know the difference between system prompts and user messages

### 🧠 Memory Shortcuts
- Use concise, structured context
- Front-load important instructions
- Exploit recency bias — last messages carry more weight

### 🔀 Parallel Conversations
- Branch for exploration, merge for results
- Use sub-agents for independent research paths
- Keep a "main thread" for integration

---

## RUA Applied to Prompt Engineering

See [[RUA-Overview]] for the full framework. Applied specifically:

- **R (Recognize):** What type of task is this? Generation? Analysis? Transformation?
- **U (Understand):** What does the AI need to know? What constraints exist?
- **A (Apply):** Test → observe response → refine prompt → iterate

---

## DO / DON'T Cheat Sheet

| DO ✅ | DON'T ❌ |
|------|---------|
| Be specific about output format | Over-assign personas |
| Provide examples for complex patterns | Use vague instructions |
| Structure reasoning steps | Say "think harder" |
| Test and iterate | Assume first prompt is perfect |
| Give the AI an "out" (say "I don't know" is OK) | Demand impossible precision |

---

## Related

- [[Boris-Anthropic-Takeaways]] — Full RUA breakdown of Boris' speech
- [[RUA-Overview]] — The learning framework
- [[Tips-Index]] — Daily prompt engineering learnings
