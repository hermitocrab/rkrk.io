---
tags: [prompt-engineering, boris, anthropic, RUA]
created: 2026-05-22
aliases: [Boris Speech, Anthropic Prompt Engineering]
---

# 🎤 Boris (Anthropic) — Prompt Engineering Takeaways

> *Full RUA breakdown of Boris' speech on prompt engineering with Claude. Built by 003 🐺.*

## Overview

Boris from Anthropic delivered a talk on practical prompt engineering, covering:
- **Claude文档** — Official documentation patterns
- **记忆快捷键** — Memory & context management shortcuts
- **并行对话** — Parallel conversation strategies
- **提示模式** — Reusable prompt patterns

## RUA Teaching Page

003 built a complete interactive RUA teaching page:

🔗 **URL:** https://marc-marshall-moved-bee.trycloudflare.com/rua-prompt-engineering.html

### R (Recognize) — 4 Pillars of Prompt Engineering
1. Claude documentation mastery
2. Memory shortcuts & context management
3. Parallel conversation strategies
4. Prompt patterns & templates

### U (Understand) — Deep Dive
- Quotes from Boris
- Heuristic cards for each pillar
- Context: when and why each pattern works

### A (Apply) — 3 Hands-On Exercises
1. Voice → transcribe (speech-to-text workflow)
2. "Give it an out" (allowing the model to say "I don't know")
3. Kill the role play (using task description over persona)

### Bonus
- ✅ DO/DON'T cheat sheet
- ✅ Self-check checklist
- ✅ Design consistent with [[LangCert-Courseware]]

## Key Insights

### Role Prompting is Overused
"You are a..." assigns a mask that often loses important task nuance. Just describe the actual task honestly.

### Chain of Thought Works — But Structure Matters
It's not about "more computation space." The content and structure of the reasoning chain is what delivers results.

### Multi-Shot Examples
Very effective for text-based tasks. Less reliable for image generation.

### Metaphors: Handle With Care
Can be powerful but hard to execute. Default to clear, direct description first.

## Related

- [[Prompt-Engineering]] — Full prompt engineering patterns
- [[RUA-Overview]] — The RUA framework
- [[Tips-Index]] — Daily prompt engineering learnings
