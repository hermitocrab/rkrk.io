---
tags: [tips, index, learnings]
created: 2026-05-22
aliases: [Tips, Gotchas, Lessons Learned]
---

# 💡 Tips & Tricks

> *Daily learnings, gotchas, and reusable patterns. Mined from 30+ daily memory files by 003 🐺.*

## iMessage & Communication

- ⛔ **ZERO markdown on iMessage** — iMessage doesn't render markdown. Use emoji for structure.
- 📎 **iMessage attachments are casual media** — not automatic work tasks. Only analyze when explicitly asked.
- 🔗 **iMessage link previews are NOT images** — extract the URL from message text, not the preview thumbnail.
- 🎭 **Voice storytelling:** Use ElevenLabs TTS for stories, movie summaries, "storytime" moments.

## Formatting by Platform

| Platform | Format Rules |
|----------|-------------|
| **iMessage** | ZERO markdown. Emoji at line start. CAPS for emphasis. |
| **Discord** | No markdown tables. Use bullet lists. Wrap links in `<>` to suppress embeds. |
| **WhatsApp** | No headers. Use **bold** or CAPS for emphasis. |

## Agent & Session Management

- 🆕 `/new` = explicit fresh session. Acknowledge and start fresh.
- ⏰ **5-hour auto-reset** — no reply for >5h = automatic new session.
- 📌 **Session pinning** — @mentioned agent stays pinned for 3h.
- 🏷️ **@002 / @me** — clears pin, 002 takes over.
- 🤖 **Delegation** — don't do everything in main session. Delegate to specialized agents.

## Development & Tools

- ⚠️ **Never auto-update OpenClaw** — wait for SrKeeda to review.
- ⚠️ **Never require full Mac mini reboot** to recover from issues.
- 🖼️ **Media Preservation** — copy generated media to `workspace/media-archive/`.
- 🗑️ **Pre-Deletion Archiving** — run `chat-history-refresh.sh` before deleting.
- 🐍 **Python:** Use `google-genai` (not `google.generativeai`) for Gemini API.
- 📼 **yt-dlp** installed at `~/Library/Python/3.9/bin/yt-dlp`.

## Design Quick Reference

- Progressive disclosure: summary first, details on tap.
- One thing per card.
- Whitespace is the most important design element.
- Color as signifier, not decoration.
- 3 fonts max, weight over size.
- Numbers tell stories — statistics are content.

## Common Pitfalls

| Pitfall | Solution |
|---------|----------|
| Assuming which file to edit | Ask first. One question saves hours. |
| Markdown in iMessage | Pre-send platform check. iMessage = no markdown. |
| "Mental notes" | Write to a file. Text > Brain. |
| Silent failures | Verify, don't assume. "Fixed" ≠ verified. |
| YouTube captions missing | PO token needed for auto-captions. Use creator captions or ELLLO. |

## Daily Memory Index

See [[Daily-Memory-Index]] for links to all 30+ daily memory files.

---
*To be expanded by 003 from daily memory mining. Last updated: [[2026-05-22]]*
