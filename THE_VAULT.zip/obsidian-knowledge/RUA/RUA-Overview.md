---
tags: [RUA, framework, learning, meta-cognition]
created: 2026-05-22
aliases: [RUA, RUA Framework, RUA Learning Method]
---

# 📚 RUA Learning Framework

> *Core framework for meta-cognitive learning in the AI era. Not content-specific — it's a "learning how to learn" operating system. Created by SrKeeda.*

## R · U · A (Top Level)

| Phase | Meaning | Focus |
|-------|---------|-------|
| **R** · Recognize | Identify & decompose the learning target | What am I dealing with? |
| **U** · Understand | Deep comprehension before application | What does this mean? |
| **A** · Apply | Systematic practice with feedback loops | Can I use this? |

---

## R: BEEF (Goal Decomposition)

*The 5W1H as a Tomahawk — must be cut into bite-sized chunks.*

| Element | Meaning |
|---------|---------|
| **B**ackground | When, where, who |
| **E**vidence | The CHOP (see below) |
| **E**xplanation | The SOOI (see below) |
| **F**eedback | How you feel; record the emotion as a signal |

### E: CHOP (Evidence Decomposition)

- **C**aught your eye — What stood out?
- **H**ighlight — What's the key takeaway?
- **O**ptimised procedure — What's the refined workflow?
- **P**urpose — Why does this exist?

### E: SOOI (Explanation Decomposition)

- **S**ubjective — Why *I* find this hard
- **O**bjective — What's the actual skill being tested
- **O**utlying — How do others approach this?
- **I**ntrinsic — Why learn this beyond the test?

---

## U: 3C (Deep Comprehension)

| Element | Question |
|---------|----------|
| **C**ollocation | What does this naturally pair with? |
| **C**ontexts | In what situations does this appear? |
| **C**onnotation | What's the unspoken/implied meaning? |

---

## A: GAP (Deliberate Practice)

| Element | Action |
|---------|--------|
| **G**auge | Where exactly is the gap? |
| **A**nalyse | Trace back to a Recognise bite-sized chunk |
| **P**ractice | Drill, fail, correct, repeat |

---

## DynamOS

Branded product layer wrapping RUA — a cognitive OS for learning anything.

Conceptually: student-side AI-era metacognition framework.

Applications: IELTS, general language learning, any self-directed study.

---

## BEEF + CHOP Visual Map

```
R · RECOGNIZE
  ├── B · Background (5W1H)
  ├── E · Evidence
  │   ├── C · Caught your eye
  │   ├── H · Highlight
  │   ├── O · Optimised procedure
  │   └── P · Purpose
  ├── E · Explanation
  │   ├── S · Subjective
  │   ├── O · Objective
  │   ├── O · Outlying
  │   └── I · Intrinsic
  └── F · Feedback (emotional signal)

U · UNDERSTAND → 3C (Collocation, Contexts, Connotation)
A · APPLY → GAP (Gauge, Analyse, Practice)
```

---
*Source: MEMORY.md RUA Learning Method section*
