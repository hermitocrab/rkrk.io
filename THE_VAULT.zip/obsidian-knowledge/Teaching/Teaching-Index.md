---
tags: [teaching, index, MOC]
created: 2026-05-22
aliases: [Teaching Arsenal, Courses]
---

# 🎓 Teaching Arsenal

> *Complete catalog of Kee Lee's teaching materials. Source: `~/Library/Mobile Documents/com~apple~CloudDocs/Teaching/` (iCloud synced)*

## 🏆 IELTS (Largest — ~500+ files)

### Listening
- 5.5 (8 lessons) + 6.5 (8 lessons) — PPTX, DOCX, audio
- 807 Vocabulary PDF with 80+ categorized MP3s
- Skills PDF, frequency word list

### Reading
- 5.5 (8 lessons) + 6.5 (8 lessons) — PPTX, worksheets, keys
- BC Lesson Plans (9 task-type activities)
- Error analysis spreadsheet, 538 key vocabulary

### Speaking
- 5.5 + 6.5 course packs with full lecture notes
- Massive Question Bank (2024-2026 quarterly updates)
- Pronunciation: 28-day audio course (28 tracks)
- Mindmaps (50+ .xmind files), worksheets, PPTX
- Band descriptors, assessment criteria

### Writing
- 5.5 (8 lessons) + 6.5 (8 lessons) — textbook-style
- Collocation guide, classified writing topics

### Textbook
- Complete IELTS 4-5 (SB, TB, WB)
- Ready for IELTS (SB+CD, WB+audio)
- Unlock L2, L3 (Listening & Speaking)
- Cambridge IELTS 2 (full)

### Vocabulary
- Collins Vocabulary for IELTS + 38 audio tracks
- Oxford 3000 & 5000 by CEFR, Academic Word List
- OPAL phrases, Discourse Markers

---

## 🏆 Other Exams

### TOEFL
- Collins COBUILD vocab/grammar
- Listening: 1200 vocabulary, TPO classified vocab
- Speaking: Task 1-4 templates, strategies book
- Longman Complete Course

### PTE
- APEUni: 10 complete lesson PPTXs + DOCXs
- SFE: Module 1-4 PPTXs (Speaking, Writing, Reading, Listening)
- Score Guides, Tutorial, Testbuilder

### Cambridge (KET/PET/FCE)
- KET: 14-unit PPTX course, Trainer audio (74 tracks)
- PET: 7 units PPTX, Complete PET (SB+WB+TB)
- FCE: B2 First Handbook

---

## 📊 Other Materials

- Business English, Grammar, Academic (A-level, Economics, Think)
- CET-4, Teaching materials, Portfolio
- PT Schools (7 institutions)
- 40+ students in NSS feedback
- 75+ interactive HTML teaching tools

---

## ⚡ Speaking P2 Project

**Deployed:** `https://ielts.rkrk.io/speaking-p2/`
**Vercel project:** `speaking-p2`

4 pages: people.html (62 cards), places.html (22 cards, 5 angles), events.html (50 cards, 5 angles), objects.html (34 cards).

Features: 3D flip cards, sentence frames, Eileen AI case studies, cross-box note-taking, 1-min/2-min timers, screenshot export, localStorage usage tracking.

**ALWAYS CHECK this directory first for PT2/P2/speaking part 2 work.**

---

## 📂 File Locations

| Path | Content |
|------|---------|
| `courses/teaching-index.md` | Complete file-level catalog |
| `courses/websites-index.md` | 75+ interactive HTML tools |
| `workspace/ielts-with-kee/speaking-p2/` | P2 project files |

### Key Assets
- 200+ PDFs, 100+ PPTXs, 150+ DOCXs
- 80+ mindmaps (xmind), 200+ audio files

---
*Source: MEMORY.md Teaching Arsenal + courses/teaching-index.md*
