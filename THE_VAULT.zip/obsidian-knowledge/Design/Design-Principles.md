---
tags: [design, principles, editorial, UI, courseware]
created: 2026-05-22
aliases: [Design, Visual Principles, Editorial Design]
---

# 🎨 Design Principles

> *Taste anchors, not checklists. When in doubt, match these vibes. Curated by SrKeeda.*

## Design Benchmarks

🎴 **Cards** — Apple Wallet flip. Smooth 3D, never a PowerPoint fade.

📰 **Editorial** — NYT Magazine. Serifs, drop caps, pull quotes, breathing room.

🎨 **Colour** — Visible gradients like a sky at sunset. Never washed-out pastels. Color as signifier, not decoration.

🔤 **Type** — Natural English a human would say. Zero ESL awkwardness.

📱 **Mobile** — Native feel. Swipe = scroll, tap = interact. Obvious to the thumb.

🧩 **Layout** — Information has a home. Nothing floats. Sidebar knows its place.

---

## Research-Backed Principles

### 1. Progressive Disclosure
Summary first, details on tap.
*Reference: Stripe, Linear, Apple*

### 2. One Thing Per Card
Never show the same data twice on one card.
*Reference: Pitchfork, Brainscape*

### 3. Breathing Room
Whitespace is the most important design element.
*Reference: Apple HIG, NYT*

### 4. Color as Signifier
Every color choice maps to data.
*Reference: Linear, Stripe*

### 5. Type Hierarchy
3 fonts max, weight over size for differentiation.
*Reference: NYT, MDN*

### 6. Numbers Tell Stories
Statistics are content, not decoration.
*Reference: Our World in Data*

### 7. Invisible Navigation
Always there, never in the way.
*Reference: Linear command palette*

---

## Reference Sites Worth Studying

- [Stripe Docs](https://stripe.com/docs)
- [Linear Docs](https://linear.app/docs)
- [Apple HIG](https://developer.apple.com/design/human-interface-guidelines)
- [Pitchfork Reviews](https://pitchfork.com/reviews/)
- [Brainscape](https://www.brainscape.com)
- [Notion Templates](https://www.notion.so/templates)
- [Our World in Data](https://ourworldindata.org)
- [A24 Films](https://a24films.com)

---

## LangCert Courseware Patterns

> *Design system for language certification courseware. See [[LangCert-Courseware]] for full spec.*

- Dark Gen Z aesthetic
- Bilingual toggle (EN / ZH-CN / ZH-TW)
- Fonts: Space Grotesk + Inter + Noto Sans SC
- Emoji at line start for visual structure
- Dual-purpose: presentation + teaching tool

---
*Source: SOUL.md Design Principles + MEMORY.md Design Benchmarks*
