---
tags: [courseware, langcert, design, B1]
created: 2026-05-22
aliases: [LangCert, Courseware, Language Certification]
---

# 📖 LangCert Courseware

> *Design system and patterns for language certification courseware. Built by 003 🐺 with SrKeeda's direction.*

## Design System

### Aesthetic
- Dark, Gen Z-friendly
- Clean, editorial feel
- Not academic-looking — approachable

### Typography
- **Headings:** Space Grotesk
- **Body:** Inter
- **Chinese:** Noto Sans SC
- **Bilingual toggle:** EN ↔ ZH-CN ↔ ZH-TW

### Color
- Dark backgrounds with vibrant accents
- Color as signifier (not decoration)
- Visible gradients

## Features

### Language Support
- 7-language dropdown (EN, ZH-CN, ZH-TW, KO, FR, JA, TH)
- Full translations for all UI labels, placeholders, prompts
- Chinese L1 support for B1 students

### Audio Player
- Script toggle (show/hide transcript)
- Speed control
- Natural conversation audio (Gemini TTS)

### Learning Features
- Discourse marker highlighting
- Paraphrase highlighting
- B2/C1 expression annotations
- B1-friendly learning path tiering

### Dual Purpose
- Presentation mode (for teachers)
- Self-study mode (for students)

## Level Structure

| Level | CEFR | Focus |
|-------|------|-------|
| L1 | A2-B1 | Foundation listening |
| L2 | B1 | Everyday conversations |
| L3 | B1+ | Extended dialogues |
| L4 | B2 | Complex topics |
| L5 | B2+ | Academic listening |
| L6 | C1 | Advanced comprehension |

## Remembered Requirements (for L3-L6)
- ✅ Chinese L1 support for B1 students
- ✅ Discourse marker + paraphrase highlighting
- ✅ Audio player with script toggle + speed control
- ✅ B2/C1 expression annotations
- ✅ B1-friendly learning path tiering
- ✅ Dual-purpose design (presentation + teaching tool)

## Related

- [[Design-Principles]] — Overall design philosophy
- [[Infrastructure]] — Pipeline for audio generation
- [[Teaching-Index]] — Full teaching arsenal
