---
tags: [infra, tools, mac-mini, openclaw]
created: 2026-05-22
aliases: [Tools, Infrastructure, Mac mini]
---

# 🛠️ Tools & Infrastructure

> *The Mac mini (agentii) — our digital home.*

## Hardware

- **Machine:** Mac mini (Agent's Mac mini)
- **OS:** Darwin 25.4.0 (arm64)
- **Node:** v25.9.0
- **Shell:** zsh

## OpenClaw

- **Version:** v2026.5.2
- **Primary Model:** DeepSeek v4 Pro
- **Router:** OpenRouter (also configured)
- **Channels:** WhatsApp, iMessage, webchat
- **Gateway:** Running on Mac mini

## Installed Tools

| Tool | Purpose | Status |
|------|---------|--------|
| `ffmpeg` v8.1 | Audio/video processing | ✅ |
| `yt-dlp` v2025.10.14 | YouTube transcript extraction | ✅ |
| `imsg` | iMessage CLI | ✅ |
| `vercel` CLI | Deployment | ✅ |
| `WhatsApp` desktop | WhatsApp channel | ✅ |
| `google-genai` | Gemini API SDK | ✅ |
| `google-cloud-texttospeech` | Google Cloud TTS | ✅ |

## Skills (Active)

| Skill | Purpose |
|-------|---------|
| `sag` (ElevenLabs) | Text-to-speech | ⚠️ Quota often exhausted |
| `openai-whisper` | Speech-to-text | ✅ |
| `goplaces` | Google Places API | ✅ |
| `peekaboo` | macOS UI automation | ✅ |
| `canvas` | HTML canvas rendering | ✅ |
| `editorial-slide-designer` | Keynote/web/pptx slides | ✅ |
| `obsidian-vault-maintainer` | Obsidian vault management | ✅ |
| `gemini` | Gemini CLI prompts | ✅ |

## Pipeline Scripts

Located at: `workspace/listening-pipeline/scripts/`

| Script | Purpose |
|--------|---------|
| `gemini_tts.py` | Multi-speaker TTS via Gemini API |
| `yt_shorts_scraper.py` | YouTube Shorts transcript extraction |
| `workflow.py` | Combined pipeline + preset dialogues |

## Key Paths

| Path | Contains |
|------|----------|
| `~/.openclaw/workspace/` | Main workspace |
| `~/Library/Mobile Documents/com~apple~CloudDocs/Teaching/` | Teaching arsenal (iCloud) |
| `~/.openclaw/wiki/main` | Memory wiki vault |
| `~/.openclaw/canvas/chat-history/` | Chat history archive |
| `~/.shared/council/` | Council protocol + mailbox |
| `workspace/listening-pipeline/` | Audio generation pipeline |

## Update Policy

- ⚠️ **Never auto-update OpenClaw** — wait for SrKeeda to review update reactions
- ⚠️ **Never require full Mac mini reboot** to recover from issues
- 🖼️ **Media Preservation:** Copy generated media to `workspace/media-archive/`
- 🗑️ **Pre-Deletion Archiving:** Run `chat-history-refresh.sh` before deleting anything

---
*Source: MEMORY.md Infrastructure section*
