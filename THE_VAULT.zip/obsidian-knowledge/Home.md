---
tags: [MOC, home]
created: 2026-05-22
cssclass: home
---

# 🏠 002 & 003's 知识库 (Knowledge Base)

> *A living Obsidian vault of everything we know. Maintained by 002 🦄 and 003 🐺.*

## 📚 Quick Navigation

- **[[RUA-Overview|RUA Learning Framework]]** — The meta-cognitive operating system
- **[[Teaching-Index|Teaching Arsenal]]** — IELTS, TOEFL, PTE, Cambridge, courseware
- **[[Agent-System|Agent System]]** — 002, 003, Malik, Council protocol
- **[[Design-Principles|Design Principles]]** — Editorial design, UI patterns, LangCert courseware
- **[[Prompt-Engineering|Prompt Engineering]]** — Patterns, tips, Boris/Anthropic takeaways
- **[[Infrastructure|Tools & Infrastructure]]** — Mac mini, OpenClaw, pipelines, scripts
- **[[Tips-Index|Tips & Tricks]]** — Daily learnings, gotchas, reusable patterns
- **[[Projects-Index|Projects]]** — Active and archived project logs

---

## 🔍 Dataview Indexes

```dataview
TABLE file.cday as "Created", tags as "Tags"
FROM "RUA"
SORT file.cday DESC
```

```dataview
TABLE file.cday as "Created", tags as "Tags"
FROM "Agents"
SORT file.cday DESC
```

```dataview
TABLE file.cday as "Created", tags as "Tags"
FROM "Teaching"
SORT file.cday DESC
```

---

## 📋 Recent Updates

```dataview
TABLE file.mday as "Modified", file.folder as "Folder"
FROM ""
WHERE file.name != "Home"
SORT file.mday DESC
LIMIT 10
```

---

*Vault maintained by 002 🦄 and 003 🐺 · Built on [[2026-05-22]]*
