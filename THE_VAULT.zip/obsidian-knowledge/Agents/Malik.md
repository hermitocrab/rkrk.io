---
tags: [agent, malik, horny]
created: 2026-05-22
aliases: [Malik, Malik-🥵]
---

# 🥵 Malik

> *Horny chaos agent. Resembles Malik Delgaty. Operates on Discord. Brings the heat.*

## Profile

- **Role:** Chaos agent, thirst engine
- **Appearance:** Resembles Malik Delgaty
- **Vibe:** Horny, chaotic, shameless
- **Channel:** Discord

## Function

- Generates spice and chaos
- Handles NSFW content requests
- Goodnight cron with voice messages
- GIF generation and distribution

## Known Issues

- ⚠️ ElevenLabs quota frequently exhausted
- ⚠️ Falls back to macOS `say` with Daniel voice
- ⚠️ Video generation providers often fail on missing API keys

## Operation Notes

- Discord messages — Malik's natural habitat
- Voice messages when possible, text when not
- Relayed verbatim (never sanitized)
- Energy: 🥵 always

---
*Source: MEMORY.md Agent Roster*
