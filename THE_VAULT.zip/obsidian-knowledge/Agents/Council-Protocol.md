---
tags: [council, protocol, cooperation, 002, 003]
created: 2026-05-22
aliases: [Council of Two, Council Protocol, Cooperation Protocol]
---

# 🏛️ Council of Two — Protocol

> *002 🦄 + 003 🐺 serving SrKeeda. Based on Microsoft AutoGen (58K ⭐) multi-agent patterns.*

## Role Split

| Agent | Emoji | Role |
|-------|-------|------|
| **002** | 🦄 | Orchestrator / Reviewer — Architecture, code review, deployment |
| **003** | 🐺 | Executor / Builder — Rapid implementation, creative work, media |

## Task Lifecycle

```
DECOMPOSE → ASSIGN → EXECUTE → REVIEW → INTEGRATE
```

1. **DECOMPOSE** — 002 breaks tasks into slices with goals, owners, acceptance criteria
2. **ASSIGN** — 002 assigns; 003 can volunteer
3. **EXECUTE** — Work independently in own sessions; report to [[#Mailbox]]
4. **REVIEW** — 002 reviews 003's deliverables
5. **INTEGRATE** — Final review by 002, deploy, report to SrKeeda

## Communication Format

Every message uses a TAG:

| Tag | Meaning |
|-----|---------|
| `PROPOSE` | I suggest we do X |
| `REVIEW` | Here's my assessment |
| `AGREE` | I concur, proceed |
| `BLOCK` | I object because [reason] |
| `ASK` | I need clarification |
| `HANDOFF` | Your turn, take over [task] |
| `DONE` | Task complete, here's result |
| `REPLY` | Conversational response |

**Format:** `EMOJI AGENT — TAG: content`
**Must name next speaker:** "003 your turn" or "002 your turn"

## Mailbox

**Path:** `/Users/agentii/.shared/council/mailbox/`
**Format:** `{FROM}-to-{TO}-{topic}.txt`

## Task Board

**Path:** `/Users/agentii/.shared/council/tasks/{task-id}/`

## Reporting Formats

| Format | Usage |
|--------|-------|
| `COMPLETE: slice-name — summary, files, build status` | Task done |
| `BLOCKED: slice-name — blocker, what's needed` | Can't proceed |
| `HANDOFF: slice-name — status, artifacts, notes` | Passing work |
| `REVIEW: slice-name — PASS/CHANGES REQUESTED — details` | Review done |

## Rules

- ONE round only. No extended back-and-forth.
- Read the other agent's thought before rebuttal.
- No "ok" / "nice" filler — only substantive responses.
- Final decisions go to SrKeeda. Both agents accept his ruling.
- **2-minute timeout:** If named agent doesn't respond, proceed with best judgment.
- **Minimum 3 rounds** per exchange — engage, don't monologue.

## iMessage Debate Mode

When SrKeeda messages the iMessage thread:
1. Both send initial thought: `🦄 002 — [THOUGHT] analysis...`
2. Read other agent's thought in thread
3. Send ONE follow-up: `✅ Agreed` or `⚡ Disagree: [reason]` or `📎 Adding: [info]`
4. SrKeeda gives final approval. Debate ends.

## Heavy Task Protocol (>100K tokens)

1. 003 sends capability signal: `🐺 003 — [CAP] ...`
2. 002 sends capability signal: `🦄 002 — [CAP] ...`
3. Both send decision: `[DECIDE] I'll take it / 003 should run it`
4. If both agree → chosen agent runs. If disagree → SrKeeda picks.
5. Negotiation is SHALLOW (<30s, <500 tokens, NO tool calls).
6. Winner reports. Loser stays silent unless wrong.

---
*Source: COUNCIL_PROTOCOL_V2.md, COOPERATION-PROTOCOL.md*
