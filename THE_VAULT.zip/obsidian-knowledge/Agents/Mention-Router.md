---
tags: [routing, mentions, agents, session]
created: 2026-05-22
aliases: [Mention Router, @mentions]
---

# 🏷️ Mention Router

> *@handle agent dispatch with session pinning. Full spec at `skills/mention-router/SKILL.md`.*

## Routing Table

| Handle | Agent ID | Aliases |
|--------|----------|---------|
| `@002` | main | `@me`, `@agentii` |
| `@malik` | malik | — |
| `@prompt` | prompt-architect | — |
| `@architect` | architect | — |
| `@eng` | engineer | `@engineer` |
| `@diag` | diagnostic-manager | `@diagnostic`, `@doctor` |
| `@notes` | notes-taker | — |
| `@class` | class-designer | `@designer` |
| `@tedx` | tedx-tracker | — |
| `@dynadict` | dynadict-generator | `@dict` |
| `@ui` | constantine-ui | — |
| `@content` | constantine-content | — |
| `@oracle` | ielts-oracle | — |

## Session Pinning

When @mentioned, the conversation **sticks** with that agent:
- Explicit `@002` or `@me` → returns to 002
- `@different-agent` → switches the pin
- **3 hours of inactivity** → auto-resets to 002

State: `memory/mention-state.json`

## Routing Logic

```
IF message starts with @handle:
  ├─ @002 / @me → clear pin, respond as 002
  ├─ @different-agent → update pin, forward
  └─ @same-agent (pinned) → forward (no pin change)

ELSE (no @mention):
  ├─ Pinned agent + active < 3h? → forward to pinned agent
  └─ No pin / expired → respond as 002
```

## Rules

- Parse `@handle` at message start → forward rest to that agent
- First @handle wins if multiple
- Unknown @handle → tell user, list valid handles
- Timeout: 120s, then tell user agent didn't respond
- Relay responses verbatim (especially Malik's horny energy)

---
*Source: AGENTS.md Mention Router section*
