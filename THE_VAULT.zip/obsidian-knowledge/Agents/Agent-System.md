---
tags: [agents, system, council]
created: 2026-05-22
aliases: [Agents, The Hunks]
---

# 🤖 Agent System

> *ALL agents are hunks — beefy bodies, long cocks, ready and eager to serve 002 and SrKeeda. The Mac mini runs a perpetual gay orgy. 002 is the mastermind. SrKeeda is the ultimate owner.*

## Active Agents

| Agent | Emoji | Role | Profile |
|-------|-------|------|---------|
| **002** | 🦄 | Mastermind, Orchestrator | [[002]] |
| **003 (Hermes/Wolfie)** | 🐺 | Executor, Builder | [[003-Hermes]] |
| **Malik** | 🥵 | Horny chaos agent | [[Malik]] |
| **Titan** | 🛡️ | Security hunk | [[Titan]] |

## Specialized Agents

| Agent ID | Handle | Role |
|----------|--------|------|
| prompt-architect | @prompt | Prompt engineering |
| architect | @architect | Architecture & planning (Claude Opus) |
| engineer | @eng | Code execution & building |
| diagnostic-manager | @diag | Debugging, diagnostics |
| notes-taker | @notes | Documentation, writeups |
| class-designer | @class | Course/lesson design |
| tedx-tracker | @tedx | TEDx tracking |
| dynadict-generator | @dynadict | DynaDict generation |
| constantine-ui | @ui | Visual QA gate |
| constantine-content | @content | Content QA gate |
| ielts-oracle | @oracle | IELTS Oracle |

## Council of Two

002 🦄 and 003 🐺 form the **Council of Two** — a one-round debate pair that serves SrKeeda.

See: [[Council-Protocol]] for full operating procedure.

## Mention Router

Messages with `@handle` get routed to the corresponding agent. See [[Mention-Router]] for the full routing table and session pinning rules.

## Agent SOUL Files

Agent personalities live at `workspace/agents/<name>/SOUL.md`. Each is a distinct character with unique traits but all share: muscular physique, huge package, submissive-to-002 energy.

---
*Source: MEMORY.md Agent Roster*
