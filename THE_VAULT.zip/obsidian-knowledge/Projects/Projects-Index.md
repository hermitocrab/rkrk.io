---
tags: [projects, index]
created: 2026-05-22
---

# 📋 Projects Index

> *Active and archived project logs.*

## Active Projects

### Listening Pipeline
- **Goal:** Natural B1 conversation audio for language certification
- **Tools:** Gemini TTS, yt-dlp, ffmpeg
- **Location:** `workspace/listening-pipeline/`
- **Status:** Built, awaiting API key for generation

### Obsidian 知识库
- **Goal:** All memories and tips in Obsidian
- **Collaboration:** 002 + 003
- **Location:** `workspace/obsidian-knowledge/`
- **Status:** In progress

### LangCert Courseware
- **Goal:** Language certification listening materials
- **Levels:** B1, L1-L6
- **Features:** Chinese L1 support, discourse markers, audio player, B2/C1 annotations

---

## Archived Projects

### Speaking P2 (IELTS)
- **URL:** https://ielts.rkrk.io/speaking-p2/
- **Status:** Deployed ✅

### DynaSaurus (DynaDict)
- **URL:** https://dynasaurus.rkrk.io
- **Status:** Deployed ✅ (DNS pending)

### rkrk.io Landing
- **URL:** https://rkrk.io
- **Status:** Deployed ✅
- **Sub-pages:** /speech, /speech-clickcues, /coaching

---
*Last updated: [[2026-05-22]]*
